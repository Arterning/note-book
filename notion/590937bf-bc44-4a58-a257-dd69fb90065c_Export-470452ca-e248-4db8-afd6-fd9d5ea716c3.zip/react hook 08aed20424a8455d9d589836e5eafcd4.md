# react hook

[useRef](useRef%20478c34a0578d43589c4c4d5a7dc37d98.md)

[useContext](useContext%201264361c1fab416fb78e199fea7ea846.md)