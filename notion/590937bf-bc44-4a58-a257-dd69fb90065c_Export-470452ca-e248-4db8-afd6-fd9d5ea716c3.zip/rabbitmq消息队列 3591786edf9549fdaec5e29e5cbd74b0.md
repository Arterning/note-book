# rabbitmq消息队列

- [参考](https://note.dolyw.com/mq/)