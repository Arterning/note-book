# background

背景颜色

```tsx
bg-{color}-{weight}
```

比如

```tsx
bg-blue-300
```

浅蓝色