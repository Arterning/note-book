# Typography

字体家族

```css
<p class="font-sans ...">The quick brown fox ...</p>
<p class="font-serif ...">The quick brown fox ...</p>
<p class="font-mono ...">The quick brown fox ...</p>
```

我感觉font-mono比较好看

```css
text-sm 小号
The quick brown fox jumps over the lazy dog.

text-base 中号
The quick brown fox jumps over the lazy dog.

text-lg 大号
The quick brown fox jumps over the lazy dog.

text-xl 大大号
The quick brown fox jumps over the lazy dog.

text-2xl
The quick brown fox jumps over the lazy dog.
```

我感觉**text-lg比较好，太小了看着费力**

Use the line-clamp-* utilities to truncate a block of text after a specific number of lines.

比如line-clamp-3 控制只展示3行，多的截断

控制行高 leading-{n}

字体颜色 text-{color}-{weight}